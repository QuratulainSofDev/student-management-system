#ifndef STACK_H
#define STACK_H

#include "Student.h"

class Stack
{
private:
    static const int maxSize = 100; // Change this value based on your needs
    Student data[maxSize];
    int topIndex;

public:
    Stack();

    // Adds a student to the top of the stack
    void push(const Student &s);

    // Removes the student from the top of the stack
    void pop();

    // Returns a reference to the student at the top of the stack
    const Student &top() const;

    // Checks if the stack is empty
    bool isEmpty() const;

    // Returns the number of students in the stack
    int size() const;
};

#endif // STACK_H
