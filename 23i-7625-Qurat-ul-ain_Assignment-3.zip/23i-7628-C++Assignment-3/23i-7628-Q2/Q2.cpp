#include "Student.h"
#include "Stack.h"
using namespace std;

int main() {
    // Creating a stack of students
    Stack studentStack;

    // Creating two students
    Student student1(12345, 3.75, 1, 0);
    Student student2(67890, 3.95, 2, 1);

    // Pushing students onto the stack
    studentStack.push(student1);
    studentStack.push(student2);

    // Displaying stack information
    cout << "Stack size: " << studentStack.size() << endl;

    // Displaying information about the top student
    cout << "Top Student Information:" << endl;
    cout << "Student ID: " << studentStack.top().getStudentID() << endl;
    cout << "GPA: " << studentStack.top().getGPA() << endl;
    cout << "Degree Status: " << studentStack.top().getDegreeStatusDescription() << endl;
    cout << "Warning Count: " << studentStack.top().getWarningCount() << endl;

    // Popping a student from the stack
    studentStack.pop();

    // Displaying stack size after pop
    cout << "\nStack size after pop: " << studentStack.size() << endl;

    return 0;
}
