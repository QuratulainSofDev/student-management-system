#include "Stack.h"
using namespace std;

Stack::Stack() : topIndex(-1) {}

void Stack::push(const Student &s)
{
    if (topIndex < maxSize - 1)
    {
        topIndex++;
        data[topIndex] = s;
    }
    else
    {
        cerr << "Error: Stack overflow." << endl;
    }
}

void Stack::pop()
{
    if (topIndex >= 0)
    {
        topIndex--;
    }
    else
    {
        cerr << "Error: Stack underflow." << endl;
    }
}

const Student &Stack::top() const
{
    if (topIndex >= 0)
    {
        return data[topIndex];
    }
    else
    {
        cerr << "Error: Stack is empty." << endl;
        // You might want to throw an exception here instead of returning an arbitrary value.
        return data[0];
    }
}

bool Stack::isEmpty() const
{
    return topIndex == -1;
}

int Stack::size() const
{
    return topIndex + 1;
}
