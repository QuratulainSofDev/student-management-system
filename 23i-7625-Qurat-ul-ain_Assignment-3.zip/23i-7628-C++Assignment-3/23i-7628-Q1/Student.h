#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <string>
#include <map>
using namespace std;

class Student
{
private:
    int studentID;
    double gpa;
    int degreeStatus;
    int warningCount;

    static const map<int, string> degreeStatusMap;

public:
    // Constructors
    Student();
    Student(int id, double gradePoint, int status, int warnings);

    // Getters
    int getStudentID() const;
    double getGPA() const;
    int getDegreeStatus() const;
    string getDegreeStatusDescription() const;
    int getWarningCount() const;

    // Setters
    void setStudentID(int id);
    void setGPA(double gradePoint);
    void setDegreeStatus(int status);
    void setWarningCount(int warnings);
};

#endif // STUDENT_H
