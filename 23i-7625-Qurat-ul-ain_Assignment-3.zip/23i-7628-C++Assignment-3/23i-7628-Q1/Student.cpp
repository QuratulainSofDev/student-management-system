#include "Student.h"
using namespace std;

// Define the degreeStatusMap outside of the class
const map<int, string> Student::degreeStatusMap = {
    {1, "Current"},
    {2, "Completed"},
    {3, "Removed"},
    {4, "Semester Freeze"}};

// Constructors
Student::Student() : studentID(0), gpa(0.0), degreeStatus(1), warningCount(0) {}

Student::Student(int id, double gradePoint, int status, int warnings)
    : studentID(id), gpa(gradePoint), degreeStatus(status), warningCount(warnings) {}

// Getters
int Student::getStudentID() const { return studentID; }

double Student::getGPA() const { return gpa; }

int Student::getDegreeStatus() const { return degreeStatus; }

string Student::getDegreeStatusDescription() const
{
    auto it = degreeStatusMap.find(degreeStatus);
    return (it != degreeStatusMap.end()) ? it->second : "Unknown";
}

int Student::getWarningCount() const { return warningCount; }

// Setters
void Student::setStudentID(int id) { studentID = id; }

void Student::setGPA(double gradePoint) { gpa = gradePoint; }

void Student::setDegreeStatus(int status) { degreeStatus = status; }

void Student::setWarningCount(int warnings) { warningCount = warnings; }
