#include "Student.h"
using namespace std;

int main()
{
    // Example usage of the Student class
    Student student1(12345, 3.75, 1, 0);

    cout << "Student ID: " << student1.getStudentID() << endl;
    cout << "GPA: " << student1.getGPA() << endl;
    cout << "Degree Status: " << student1.getDegreeStatusDescription() << endl;
    cout << "Warning Count: " << student1.getWarningCount() << endl;

    // Update student information
    student1.setGPA(3.85);
    student1.setWarningCount(1);
    student1.setDegreeStatus(4);

    cout << "\nUpdated Student Information:" << endl;
    cout << "GPA: " << student1.getGPA() << endl;
    cout << "Degree Status: " << student1.getDegreeStatusDescription() << endl;
    cout << "Warning Count: " << student1.getWarningCount() << endl;

    return 0;
}
