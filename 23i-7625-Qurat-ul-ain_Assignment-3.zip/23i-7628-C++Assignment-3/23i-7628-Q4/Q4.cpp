#include "BST.h"
using namespace std;

int main() {
    BST studentBST;

    // Inserting students into the BST
    studentBST.insert(Student(12345, 3.75, 1, 0));
    studentBST.insert(Student(67890, 3.95, 2, 1));
    studentBST.insert(Student(11111, 3.85, 1, 2));

    // Displaying the BST
    cout << "Binary Search Tree:" << endl;
    studentBST.display();

    // Removing a student by ID
    studentBST.removeNode(67890);

    // Removing students by degree status
    studentBST.remove(1);

    // Displaying the updated BST
    cout << "\nBinary Search Tree after Removals:" << endl;
    studentBST.display();

    // Displaying size of the BST
    cout << "\nSize of Binary Search Tree: " << studentBST.size() << endl;

    // Displaying average GPA in the BST
    cout << "Average GPA in Binary Search Tree: " << studentBST.averageGPA() << endl;

    // Displaying minimum and maximum GPA in the BST
    cout << "Minimum GPA in Binary Search Tree: " << studentBST.getMinGPA() << endl;
    cout << "Maximum GPA in Binary Search Tree: " << studentBST.getMaxGPA() << endl;

    // Displaying height of the BST
    cout << "Height of Binary Search Tree: " << studentBST.height() << endl;

    return 0;
}
