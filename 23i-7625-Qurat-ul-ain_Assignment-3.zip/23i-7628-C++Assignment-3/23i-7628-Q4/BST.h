#ifndef BST_H
#define BST_H

#include "BSTNode.h"

class BST {
private:
    BSTNode* root;

    void insert(BSTNode*& node, const Student& s);
    void removeNode(BSTNode*& node, int ID);
    void removeByDegreeStatus(BSTNode*& node, int degreeStatus);
    int size(const BSTNode* node) const;
    void display(const BSTNode* node) const;
    double averageGPA(const BSTNode* node, double& sum, int& count) const;
    int height(const BSTNode* node) const;

public:
    BST();
    ~BST();

    void insert(const Student& s);
    void removeNode(int ID);
    void remove(int degreeStatus);
    int size() const;
    void display() const;
    double averageGPA() const;
    double getMinGPA() const;
    double getMaxGPA() const;
    int height() const;
};

#endif // BST_H
