#ifndef BSTNODE_H
#define BSTNODE_H

#include "Student.h"

class BSTNode {
public:
    Student data;
    BSTNode* left;
    BSTNode* right;

    BSTNode(const Student& student) : data(student), left(nullptr), right(nullptr) {}
};

#endif // BSTNODE_H
