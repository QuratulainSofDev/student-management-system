#include "BST.h"
using namespace std;
BST::BST() : root(nullptr) {}

BST::~BST() {
    // Implement a post-order traversal to delete all nodes
    while (root) {
        removeNode(root->data.getStudentID());
    }
}

void BST::insert(const Student& s) {
    insert(root, s);
}

void BST::removeNode(int ID) {
    removeNode(root, ID);
}

void BST::remove(int degreeStatus) {
    removeByDegreeStatus(root, degreeStatus);
}

int BST::size() const {
    return size(root);
}

void BST::display() const {
    display(root);
    cout << endl;
}

double BST::averageGPA() const {
    double sum = 0;
    int count = 0;
    return averageGPA(root, sum, count);
}

double BST::getMinGPA() const {
    BSTNode* current = root;

    while (current->left) {
        current = current->left;
    }

    return current->data.getGPA();
}

double BST::getMaxGPA() const {
    BSTNode* current = root;

    while (current->right) {
        current = current->right;
    }

    return current->data.getGPA();
}

int BST::height() const {
    return height(root);
}

void BST::insert(BSTNode*& node, const Student& s) {
    if (!node) {
        node = new BSTNode(s);
    } else if (s.getStudentID() < node->data.getStudentID()) {
        insert(node->left, s);
    } else {
        insert(node->right, s);
    }
}

void BST::removeNode(BSTNode*& node, int ID) {
    if (!node) {
        return;
    }

    if (ID < node->data.getStudentID()) {
        removeNode(node->left, ID);
    } else if (ID > node->data.getStudentID()) {
        removeNode(node->right, ID);
    } else {
        // Node to be deleted found

        // Case 1: Node with only one child or no child
        if (!node->left) {
            BSTNode* temp = node->right;
            delete node;
            node = temp;
        } else if (!node->right) {
            BSTNode* temp = node->left;
            delete node;
            node = temp;
        } else {
            // Case 3: Node with two children
            BSTNode* temp = node->right;

            while (temp->left) {
                temp = temp->left;
            }

            // Copy the inorder successor's data to this node
            node->data = temp->data;

            // Delete the inorder successor
            removeNode(node->right, temp->data.getStudentID());
        }
    }
}

void BST::removeByDegreeStatus(BSTNode*& node, int degreeStatus) {
    if (!node) {
        return;
    }

    if (degreeStatus < node->data.getDegreeStatus()) {
        removeByDegreeStatus(node->left, degreeStatus);
    } else if (degreeStatus > node->data.getDegreeStatus()) {
        removeByDegreeStatus(node->right, degreeStatus);
    } else {
        // Node to be deleted found
        removeNode(node, node->data.getStudentID());
        removeByDegreeStatus(node, degreeStatus); // Continue searching for more nodes with the same degreeStatus
    }
}

int BST::size(const BSTNode* node) const {
    if (!node) {
        return 0;
    }

    return 1 + size(node->left) + size(node->right);
}

void BST::display(const BSTNode* node) const {
    if (node) {
        display(node->left);
        cout << "Student ID: " << node->data.getStudentID() << " | ";
        display(node->right);
    }
}

double BST::averageGPA(const BSTNode* node, double& sum, int& count) const {
    if (node) {
        averageGPA(node->left, sum, count);
        sum += node->data.getGPA();
        count++;
        averageGPA(node->right, sum, count);
    }

    return count == 0 ? 0 : sum / count;
}

int BST::height(const BSTNode* node) const {
    if (!node) {
        return 0;
    }

    int leftHeight = height(node->left);
    int rightHeight = height(node->right);

    return 1 + max(leftHeight, rightHeight);
}
