#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "Student.h"

class Node {
public:
    Student data;
    Node* next;

    Node(const Student& student) : data(student), next(nullptr) {}
};

class LinkedList {
private:
    Node* head;

public:
    LinkedList();
    ~LinkedList();

    // Inserts a student at the front of the list
    void insertFront(const Student& s);

    // Deletes a node with a given student ID
    void deleteNode(int ID);

    // Deletes nodes with a given degree status
    void deleteByDegreeStatus(int degreeStatus);

    // Displays information for a specific student by ID
    bool display(int ID) const;

    // Returns the size of the linked list
    int size() const;

    // Displays statistics based on degree status
    void showDegreeStatusStat() const;

    // Returns a new linked list with reversed elements
    LinkedList reverse() const;

    // Rotates the list to the left by k positions
    void rotateLeft(int k);

    // Rotates the list to the right by k positions
    void rotateRight(int k);

    // Displays the linked list
    void displayList() const;
};

#endif // LINKEDLIST_H
