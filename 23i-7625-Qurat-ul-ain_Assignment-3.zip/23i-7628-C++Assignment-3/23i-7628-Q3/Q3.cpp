#include "LinkedList.h"
using namespace std;

int main()
{
    LinkedList studentList;

    // Inserting students at the front of the list
    studentList.insertFront(Student(12345, 3.75, 1, 0));
    studentList.insertFront(Student(67890, 3.95, 2, 1));
    studentList.insertFront(Student(11111, 3.85, 1, 2));

    // Displaying the initial list
    cout << "Initial Linked List:" << endl;
    studentList.displayList();
    cout << "Size: " << studentList.size() << endl;

    // Deleting a student by ID
    studentList.deleteNode(67890);

    // Deleting students by degree status
    studentList.deleteByDegreeStatus(1);

    // Displaying the updated list
    cout << "\nLinked List after Deletions:" << endl;
    studentList.displayList();
    cout << "Size: " << studentList.size() << endl;

    // Displaying information for a specific student
    studentList.display(11111);

    // Displaying degree status statistics
    studentList.showDegreeStatusStat();

    // Reversing the linked list
    LinkedList reversedList = studentList.reverse();

    // Displaying the reversed list
    cout << "\nReversed Linked List:" << endl;
    reversedList.displayList();

    // Rotating the list to the left
    studentList.rotateLeft(2);

    // Displaying the list after left rotation
    cout << "\nLinked List after Left Rotation:" << endl;
    studentList.displayList();

    // Rotating the list to the right
    studentList.rotateRight(1);

    // Displaying the list after right rotation
    cout << "\nLinked List after Right Rotation:" << endl;
    studentList.displayList();

    return 0;
}
