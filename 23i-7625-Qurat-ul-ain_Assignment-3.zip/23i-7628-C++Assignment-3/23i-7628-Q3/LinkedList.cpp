#include "LinkedList.h"
using namespace std;

LinkedList::LinkedList() : head(nullptr) {}

LinkedList::~LinkedList() {
    Node* current = head;
    while (current) {
        Node* next = current->next;
        delete current;
        current = next;
    }
}

void LinkedList::insertFront(const Student& s) {
    // Create a new node with the given student data
    Node* newNode = new Node(s);

    // Set the next pointer of the new node to the current head
    newNode->next = head;

    // Update the head to be the new node
    head = newNode;
}

void LinkedList::deleteNode(int ID) {
    Node* current = head;
    Node* prev = nullptr;

    // Traverse the list to find the node with the specified ID
    while (current && current->data.getStudentID() != ID) {
        prev = current;
        current = current->next;
    }

    // If the node is found, update the pointers and delete the node
    if (current) {
        if (prev) {
            prev->next = current->next;
        } else {
            head = current->next;
        }

        delete current;
    }
}

void LinkedList::deleteByDegreeStatus(int degreeStatus) {
    Node* current = head;
    Node* prev = nullptr;

    // Traverse the list to find nodes with the specified degree status
    while (current) {
        if (current->data.getDegreeStatus() == degreeStatus) {
            if (prev) {
                prev->next = current->next;
                delete current;
                current = prev->next;
            } else {
                Node* temp = current;
                head = current->next;
                delete temp;
                current = head;
            }
        } else {
            prev = current;
            current = current->next;
        }
    }
}

bool LinkedList::display(int ID) const {
    Node* current = head;

    // Traverse the list to find the node with the specified ID
    while (current) {
        if (current->data.getStudentID() == ID) {
            // Display information for the found student
            cout << "Student found:" << endl;
            cout << "Student ID: " << current->data.getStudentID() << endl;
            cout << "GPA: " << current->data.getGPA() << endl;
            cout << "Degree Status: " << current->data.getDegreeStatusDescription() << endl;
            cout << "Warning Count: " << current->data.getWarningCount() << endl;
            return true;
        }

        current = current->next;
    }

    // Student with the specified ID not found
    cout << "Student with ID " << ID << " not found." << endl;
    return false;
}

int LinkedList::size() const {
    int count = 0;
    Node* current = head;

    // Traverse the list to count the number of nodes
    while (current) {
        count++;
        current = current->next;
    }

    return count;
}

void LinkedList::showDegreeStatusStat() const {
    map<int, int> degreeStatusCount;

    Node* current = head;

    // Traverse the list to count the occurrences of each degree status
    while (current) {
        int status = current->data.getDegreeStatus();
        degreeStatusCount[status]++;
        current = current->next;
    }

    // Display degree status statistics
    cout << "Degree Status Statistics:" << endl;
    for (const auto& entry : degreeStatusCount) {
        cout << "Status " << entry.first << ": " << entry.second << " students" << endl;
    }
}

LinkedList LinkedList::reverse() const {
    LinkedList reversedList;
    Node* current = head;

    // Traverse the list to insert elements at the front of the reversed list
    while (current) {
        reversedList.insertFront(current->data);
        current = current->next;
    }

    return reversedList;
}

void LinkedList::rotateLeft(int k) {
    // Check for valid rotation parameter and non-empty list
    if (k <= 0 || !head) {
        return;
    }

    int count = 0;
    Node* current = head;

    // Traverse the list to find the k-th node
    while (current && count < k - 1) {
        current = current->next;
        count++;
    }

    // Return if the list is shorter than k elements
    if (!current) {
        return;
    }

    // Update pointers for left rotation
    Node* newHead = current->next;
    current->next = nullptr;

    Node* temp = newHead;
    while (temp->next) {
        temp = temp->next;
    }

    temp->next = head;
    head = newHead;
}

void LinkedList::rotateRight(int k) {
    // Get the size of the list
    int listSize = size();

    // Check for valid rotation parameter and non-empty list
    if (k <= 0 || !head || k % listSize == 0) {
        return;
    }

    // Adjust k to the equivalent rotation within the size of the list
    k = k % listSize;

    int count = 0;
    Node* current = head;

    // Traverse the list to find the (size - k - 1)-th node
    while (current && count < listSize - k - 1) {
        current = current->next;
        count++;
    }

    // Return if the list is shorter than k elements
    if (!current) {
        return;
    }

    // Update pointers for right rotation
    Node* newHead = current->next;
    current->next = nullptr;

    Node* temp = newHead;
    while (temp->next) {
        temp = temp->next;
    }

    temp->next = head;
    head = newHead;
}

void LinkedList::displayList() const {
    Node* current = head;

    // Traverse the list to display each node
    while (current) {
        cout << "Student ID: " << current->data.getStudentID() << " | ";
        current = current->next;
    }

    cout << "NULL" << endl;
}
